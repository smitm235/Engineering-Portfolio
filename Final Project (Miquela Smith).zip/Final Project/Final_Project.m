%{
Miquela Smith
smitm235@my.erau.edu
Started: March 25, 2022
Last Edited: April 30, 2022
EGR 115 - section 05

Assignment: Final Project-First Draft
Problem: This code will be able to run the game "Close the Box". The main objective 
of this game is to close the box or close each slot in the box.The rules
of the game are simple the player is given two dice and a box with 12 slots
that must be "closed". The player will role the dice and add up both of the
numbers presented on the dice. With this total the player may choose as
many slots to close, that add up to the total. If the player roles a total too high
close anymore slots then the game is over. If the player is able to close
all the slots the game is over and they have won the game. 

Rules: 
1. You may roll the dice an infinite amount of times until you finish the
game.
2. You may not select a slot again once it has already been closed.
3. You must play the game until all the slots are closed in order to
complete the game.
4. Always use the admin functions between each game to ensure MATLAB runs
the code smoothly. 

Acknowledgements: Diana Sears (Senior, AE) helped with overall code and gui
implementations. 
- She helped me to understand how to use the uifigure and the gui windows
to make my code run outside of the command window. 
- She helped me to understand how I should go about coding my project in a
way that was not confusing to me. 
fig.UserData found from: https://www.mathworks.com/help/matlab/creating_guis/share-data-among-callbacks.html
- This was used to help me to pull the updates sum of the dice out to the 
main code. As you are not usually able to pull data from a function I
looked on the MATLAB info page to see how I would be able to solve this
problem. 
All comment are located at the end of each line of code and or below (
defined by ^) or above the line of code it describes. 
%}

clear
clc
close all
close all hidden

%% Indroduction
img = imread('Welcome_Image.jpg'); % This line of code imports the image presented on the welcome message box. 
% ^ File Input ^ % 
uiwait(msgbox('Welcome to "Close the Box"!','Hello','custom',img)); % Welcome sentence. This line of code opens a message box that will uses a uiwait to stop the box from closing message box before the user presses the ok button.

%% Create Slots
slots_open_pos = [0 1 2 3 3 3 3 2 1 0 0 0;0 0 0 0 1 2 3 3 3 3 2 1]; % This line of code postitions the boxes in the gui showing the open boxes. 
open_slots = 1:1:12; % This line of code opens the matrix of slots open numbering from one to twelve for the user to close.
figure(1) % This line is the figure of that the scatter plot will be printed on. 
scatter(slots_open_pos(1,:),slots_open_pos(2,:),1000,"black",'s') % This line opens the scatter plot where the use can view the open and closed slots throughout the game.
title("Open Slots") % This line puts a title on the scatter plot, letting the user know what the plot is for.
axis([-1 4, -1 4]) % This line defines the axis of the scatter plot.
% ^ Display plot ^ %
for i = 1:length(open_slots) % 
    text(slots_open_pos(1,i),slots_open_pos(2,i),num2str(open_slots(i))) % 
end
% ^ For Loop & String ^ % 
axis square; % This line defines makes the scatter plot a square.
axis off; % This sline turn off the axis to make the scatter plot more asthetically.
hold on; % This line holds the changes make to the scatter plot. 

%% Create checkboxes
fig = uifigure('Name','Choose Slots','Position',[100 100 250 320]); % This line creates a uifigure that will hold the information that will instruct the user how to play the game.
pos = 260:-20:20; % This line positions the 

for i = 1:length(open_slots) % This line is the start of a fo loop that opens checkboxs for the user to select which slot they would like to close based on the random roll. 
    cbx{i} = uicheckbox(fig,'Text',sprintf('%d',open_slots(i)),'Position',[20 str2double(sprintf('%d',pos(i))) 84 22]); % This line creaes checkboxes that the user can select to close certain slots on the scatter plot.
    % String Function ^ % 
end % This is the end of the for.
% ^ For Loop ^ %
label1 = uilabel(fig,'Text','Please roll the dice.','Position',[20 280 150 50]); % This line 
label2 = uilabel(fig,'Text','','Position',[100 250 80 40]); % This line 
fig.UserData{2} = open_slots;

%% Create buttons
% Roll dice button
roll_dice_btn = uibutton(fig,'Text','Roll Dice','Position',[120 10 84 22],'ButtonPushedFcn',@(btn,event) roll_dice(label1,label2,fig)); % This line creates a new button in the uifigure, where the user can re-roll their dice if they can not close any of the open slots with the given random roll.
% Submit button - close the slots that are selected
submit_btn = uibutton(fig,'Text','Submit','Position',[20 10 84 22],'ButtonPushedFcn',@(btn,event) close_slots(cbx,slots_open_pos,fig,label1,label2)); % This line creates a new button in the uifigure, where the user will push the button to submit the slot the user would like to close. 

%% LOOP
while any(open_slots) % While any of the slot are still open then

    % Wait for user action
    uiwait(fig) % This line makes sure the uifigure does not leave the user screen before the user presses either the roll again button or the submit button.
  
    % Update open slots
    open_slots = fig.UserData{2}; % This line will update the 
    % ^ Array Manipulation ^ %
end
% ^ While Loop ^ %

%% Congrats message
c = msgbox("Congratulations you have Closed the Box !","Good Job !");    % This line is the CLosing message that will show when the user has completed the game.