function close_slots(cbx,slots_open_pos,fig,label1,label2) % This function calls the cbx,slot_open_pos, fig, label1 and label2 to check is the user which slots the user has selected and validates that the use rhas selected a correct amount of slots for the given roll.
% ^ Programmer-defined function calls and Input values to programmer-defined functions ^ % 
    sum_selected = 0; 
    sum_roll = fig.UserData{1}; % The sum_roll is defined as fig.UserData{1} 
    open_slots = fig.UserData{2}; % The open_slots is defined as fig.UserData{2}
    save_selected = []; % This is an empty array that will sort the selected values on the code runs the validation code. 
    % ^ Array manipulation ^ % 
    for i = 1:length(cbx)
    % For Loop %
        if cbx{i}.Value == 1 % If the user selects the box the code will checkbox is selected (Relational Operators)
        % ^ If Statement ^ % 
            sum_selected = sum_selected + i; % add to sum selected
            save_selected(end+1) = i; %
        end
        % uncheck all boxes
        cbx{i}.Value = 0; % This line checks to see which check boxes have not been checked by the user. 
    end
    % ^ Nest of Statments ^ % 
    % Input Validation
    % Find zeros in open_slots
    closed_slots = find(open_slots == 0); % This line searches through open slot to determine which slot have been closed by the user in the most recent turn and the part turns. 
    if sum_selected == sum_roll && ~any(ismember(closed_slots,save_selected)) % This line checks that correct sum was selected AND that slots already closed weren't selected.  v 
        %  ^ Boolean Operations ^ %
        % If so, close selected slots
        for k = 1:length(save_selected) % This line is defined k as the length of the saved selected. 
            scatter(slots_open_pos(1,save_selected(k)),slots_open_pos(2,save_selected(k)),1000,"black","filled","s"); % This line fills the slots the user chose in the scatter plot. 
            hold on; % This line makes sure any changes of made to the scatter plot stays on the scatter instead of updating the scatter plot without the new filled in closed slots. 
            % Update Open Slots: These next lines of code update the opens slots in the array this checking the 1's and 0's, or open and closed slots.
            open_slots(save_selected(k)) = 0; % This line ensures that the open slots are read as 0. 
            fig.UserData{2} = open_slots; % This line of code defines the open slots as the fig.UserData{2}.
            label1.Text = 'Please roll again.'; % This line changes the message in the uifigure box to direct the use to roll the dice again.
            label2.Text = ''; % This line leaves the second label in the uifigure empty until the next dice are rolled again. 
            uiresume(fig) % This line resume the figure, so the code can update the figure. 
        end
    else
        % If not, error message
        msgbox(sprintf('Please select open slots that add up to %d',sum_roll),'Error!','error') % This line of code prints out an error message when the user input an incorrect input in the uifigure. 
    end
end
% Nesting of Statements %