function roll_dice(label1,label2,fig) % This function pulls the label1, label2, and fig to run this protion of thsi code. 
    % Roll dice
    dice1 = randi([1 6]); % This line outputs a random number off a dice.
    dice2 = randi([1 6]); % This line outputs a second random number off a dice. 
    sum_roll = dice1 + dice2; % This line of code adds up the two random dice rolls to output to the user.
% ^ Random Number Generator and Running Total ^ %
    % Change figure labels
    label1.Text = sprintf("Please choose slots whose\nnumbers add up to %d",sum_roll); % This line changes the message in the uifigure to inform the user of the next steps they must take and the total amount the user rolled. 
    label2.Text = sprintf("Dice 1:   %d\nDice 2:   %d",dice1,dice2); % This line lets the user know in the uifigure what numbers they rolled on the two dice.
    
    % Save sum roll
    fig.UserData{1} = sum_roll; % This line of code enables the main code to call the the data to update the sum roll from the function. 

    uiresume(fig) % This line resumes the figure.
end